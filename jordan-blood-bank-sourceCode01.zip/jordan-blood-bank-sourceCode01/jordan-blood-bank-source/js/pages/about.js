'use strict';

function aboutPage() {
  const icons = ['♥','◫','↔','✎','✓'];
  return '<main id="main">' + pageHero(t('about'),t('aboutTitle'),t('aboutLead')) + '<section class="section" style="padding-top:20px"><div class="container">' +
    '<div class="about-intro"><article class="card about-signature"><h2>' + t('conceptTitle') + '</h2><p>' + t('conceptText') + '</p></article><article class="card about-copy"><h2>' + t('storyTitle') + '</h2><p>' + t('storyText') + '</p><span class="eyebrow">' + t('educational') + '</span></article></div>' +
    '<div class="section-head" style="margin-top:36px"><div class="section-title"><h2>' + t('goalsTitle') + '</h2></div></div><div class="goals-grid">' + t('goalItems').map(function(item,index){return '<article class="card goal-card"><span>'+icons[index]+'</span><b>'+item+'</b></article>';}).join('') + '</div>' +
    '<div class="pillars"><article class="card pillar"><div class="mini-icon">01</div><h3>' + t('mission') + '</h3><p>' + t('missionText') + '</p></article><article class="card pillar"><div class="mini-icon">02</div><h3>' + t('vision') + '</h3><p>' + t('visionText') + '</p></article><article class="card pillar"><div class="mini-icon">03</div><h3>' + t('values') + '</h3><p>' + t('valuesText') + '</p><div class="values"><span class="value">Privacy</span><span class="value">Safety</span><span class="value">Clarity</span></div></article></div>' +
    '<article class="card contact-card"><div><span class="eyebrow">' + t('fictional') + '</span><h2>' + t('contactTitle') + '</h2><p>' + t('contactText') + '</p></div><div class="contact-list"><span>Info@jordan-bloodbank.jo</span><span>+962 6 660 5555</span><span>Amman, Jordan</span></div></article>' +
    '</div></section></main>';
}

