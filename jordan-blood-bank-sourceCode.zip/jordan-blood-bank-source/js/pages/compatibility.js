'use strict';

function compatibilityPage() {
  const options = APP_CONFIG.bloodGroups.map(function(g){return '<option value="'+g+'">'+g+'</option>';}).join('');
  const rows = APP_CONFIG.bloodGroups.map(function(donor){ return '<tr><th scope="row">'+donor+'</th>' + APP_CONFIG.bloodGroups.map(function(recipient){ return '<td class="'+(RBC_COMPATIBILITY[donor].includes(recipient)?'yes':'no')+'" aria-label="'+(RBC_COMPATIBILITY[donor].includes(recipient)?'Yes':'No')+'">'+(RBC_COMPATIBILITY[donor].includes(recipient)?'✓':'—')+'</td>'; }).join('') + '</tr>'; }).join('');
  return '<main id="main">' + pageHero(t('compatibility'),t('compatTitle'),t('compatLead')) + '<section class="section" style="padding-top:20px"><div class="container">' +
    '<div class="card compat-box"><div class="compat-fields">' + selectField('donorType',t('donorType'),options) + selectField('recipientType',t('recipientType'),options) + '<button class="btn btn-primary" id="compat-test" type="button">' + t('test') + '</button></div><div class="result-panel" id="compat-result" role="status" aria-live="polite"></div></div>' +
    '<div class="table-wrap"><table class="compat-table"><caption>' + t('tableTitle') + '</caption><thead><tr><th scope="col">' + t('donorRecipient') + '</th>' + APP_CONFIG.bloodGroups.map(function(g){return '<th scope="col">'+g+'</th>';}).join('') + '</tr></thead><tbody>' + rows + '</tbody></table></div><p class="clinical-note">' + t('clinicalNote') + '</p></div></section></main>';
}

