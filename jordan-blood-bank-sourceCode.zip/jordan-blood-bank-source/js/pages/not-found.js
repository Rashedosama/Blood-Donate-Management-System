'use strict';

function notFoundPage() {
  return '<main id="main" class="not-found"><div><div class="not-found-code">404</div><h1>' + t('notFoundTitle') + '</h1><p>' + t('notFoundText') + '</p><a href="/" data-link class="btn btn-primary">' + t('backHome') + '</a></div></main>';
}

