'use strict';

function homePage() {
  const total = APP_CONFIG.bloodGroups.reduce(function(sum, group) { return sum + state.inventory[group]; }, 0);
  return '<main id="main">' +
    '<section class="hero"><div class="container hero-grid"><div class="hero-copy"><span class="eyebrow">' + t('heroEye') + '</span><h1>' + t('heroTitle') + '</h1><p class="hero-lead">' + t('heroLead') + '</p><div class="hero-actions"><a href="/donate" data-link class="btn btn-primary">' + t('startDonation') + ' ←</a><a href="/compatibility" data-link class="btn btn-secondary">' + t('testCompatibility') + '</a></div><p class="hero-note">● ' + t('demoPrivacy') + '</p></div>' +
    '<div class="hero-visual" aria-hidden="true"><div class="visual-orbit"><div class="float-pill one">O−<small>' + t('available') + '</small></div><div class="heart-card"><div class="drop"></div><strong>' + t('messageTitle') + '</strong></div><div class="float-pill two">AB+<small>' + t('available') + '</small></div></div></div></div></section>' +
    '<section class="stats-strip"><div class="container stats-grid"><div class="stat"><strong>' + total + '</strong><span>' + t('readyUnits') + '</span></div><div class="stat"><strong>8</strong><span>' + t('bloodTypes') + '</span></div><div class="stat"><strong>12</strong><span>' + t('governorates') + '</span></div><div class="stat"><strong>100%</strong><span>' + t('privacyStat') + '</span></div></div></section>' +
    '<section class="section"><div class="container"><div class="section-head"><div class="section-title"><span class="eyebrow">' + t('inventoryEye') + '</span><h2>' + t('inventoryTitle') + '</h2><p>' + t('inventoryLead') + '</p></div><div class="update-chip">' + t('lastUpdate') + ': ' + t('updateNow') + '</div></div><div class="inventory-grid">' + APP_CONFIG.bloodGroups.map(bloodCard).join('') + '</div></div></section>' +
    '<section class="section section-soft"><div class="container"><div class="message-card"><div><h2>' + t('messageTitle') + '</h2><p>' + t('messageText') + '</p></div><a href="/donate" data-link class="btn">' + t('startDonation') + '</a></div></div></section></main>';
}

