'use strict';

function donationPage() {
  const groupOptions = APP_CONFIG.bloodGroups.map(function(g) { return '<option value="' + g + '">' + g + '</option>'; }).join('');
  const govOptions = GOVERNORATES.map(function(g) { return '<option value="' + g.en + '">' + g[state.lang] + '</option>'; }).join('');
  const conditions = disqualifyingConditions.map(function(c) { return '<label class="check-card ' + (c.id === 'none' ? 'none' : '') + '"><input type="checkbox" name="conditions" value="' + c.id + '"><span>' + c[state.lang] + '</span></label>'; }).join('');
  return '<main id="main">' + pageHero(t('donate'), t('donationPageTitle'), t('donationPageLead')) +
    '<section class="section" style="padding-top:20px"><div class="container content-grid"><form class="card form-card" id="donation-form" novalidate>' +
    '<section class="form-section"><div class="form-section-title"><span>01</span><h2>' + t('personal') + '</h2></div><div class="fields four">' +
    field('firstName',t('firstName'),'text',{autocomplete:'given-name'}) + field('fatherName',t('fatherName'),'text') + field('grandfatherName',t('grandfatherName'),'text') + field('familyName',t('familyName'),'text',{autocomplete:'family-name'}) + '</div><div class="fields" style="margin-top:17px">' +
    '<div class="field"><label class="required" for="nationalId">' + t('nationalId') + '</label><input class="input" id="nationalId" name="nationalId" type="text" inputmode="numeric" maxlength="10" autocomplete="off" required><span class="hint">' + t('nationalHint') + '</span><span class="error" id="nationalId-error"></span></div>' +
    '<div class="field"><label class="required" for="phone">' + t('phone') + '</label><input class="input" id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" required><span class="hint">' + t('phoneHint') + '</span><span class="error" id="phone-error"></span></div>' +
    '<div class="field"><span class="label required">' + t('gender') + '</span><div class="choice-row"><label class="choice"><input type="radio" name="gender" value="male"><span>' + t('male') + '</span></label><label class="choice"><input type="radio" name="gender" value="female"><span>' + t('female') + '</span></label></div><span class="error" id="gender-error"></span></div>' +
    '<div class="field"><label class="required" for="age">' + t('age') + '</label><input class="input" id="age" name="age" type="number" min="' + APP_CONFIG.donationAge.min + '" max="' + APP_CONFIG.donationAge.max + '" inputmode="numeric" required><span class="hint">' + t('ageRange',{min:APP_CONFIG.donationAge.min,max:APP_CONFIG.donationAge.max}) + '</span><span class="error" id="age-error"></span></div>' +
    selectField('bloodGroup',t('bloodGroup'),groupOptions) + '</div></section>' +
    '<section class="form-section"><div class="form-section-title"><span>02</span><h2>' + t('location') + '</h2></div><div class="fields">' + selectField('governorate',t('governorate'),govOptions) + field('street',t('street'),'text',{autocomplete:'address-line2'}) +
    '<div class="field full"><label class="required" for="address">' + t('address') + '</label><textarea id="address" name="address" autocomplete="street-address" required></textarea><span class="error" id="address-error"></span></div></div></section>' +
    '<section class="form-section"><div class="form-section-title"><span>03</span><h2>' + t('medical') + '</h2></div><span class="label required">' + t('medicalPrompt') + '</span><div class="conditions-grid">' + conditions + '</div><span class="hint">' + t('medicalNote') + '</span><span class="error" id="conditions-error"></span></section>' +
    '<section class="form-section"><div class="form-section-title"><span>04</span><h2>' + t('confirmation') + '</h2></div><label class="confirm-box"><input id="confirm" name="confirm" type="checkbox"><span>' + t('confirmText') + '</span></label><span class="error" id="confirm-error"></span></section>' +
    '<button class="btn btn-primary btn-block" type="submit">' + t('submit') + '</button></form>' +
    '<aside class="side-stack"><div class="card info-card privacy-card"><div class="mini-icon">⌁</div><h3>' + t('privacyTitle') + '</h3><p>' + t('privacyText') + '</p></div><div class="card info-card"><div class="mini-icon">✓</div><h3>' + t('beforeTitle') + '</h3><ul>' + t('beforeList').map(function(i){return '<li>'+i+'</li>';}).join('') + '</ul></div></aside>' +
    '</div></section></main>';
}

