'use strict';

const APP_CONFIG = Object.freeze({
  donationAge: Object.freeze({ min: 18, max: 65 }),
  lowStockThreshold: 10,
  targetUnitsPerGroup: 40,
  inventoryKey: 'jbb_demo_inventory_v1',
  languageKey: 'jbb_language_v1',
  defaultInventory: Object.freeze({ 'O−': 7, 'O+': 34, 'A−': 11, 'A+': 28, 'B−': 8, 'B+': 21, 'AB−': 5, 'AB+': 15 }),
  bloodGroups: Object.freeze(['O−', 'O+', 'A−', 'A+', 'B−', 'B+', 'AB−', 'AB+'])
});

const GOVERNORATES = Object.freeze([
  { ar:'العاصمة عمّان', en:'Amman' }, { ar:'إربد', en:'Irbid' }, { ar:'الزرقاء', en:'Zarqa' },
  { ar:'البلقاء', en:'Balqa' }, { ar:'المفرق', en:'Mafraq' }, { ar:'جرش', en:'Jerash' },
  { ar:'عجلون', en:'Ajloun' }, { ar:'مادبا', en:'Madaba' }, { ar:'الكرك', en:'Karak' },
  { ar:'الطفيلة', en:'Tafilah' }, { ar:'معان', en:'Ma\'an' }, { ar:'العقبة', en:'Aqaba' }
]);

