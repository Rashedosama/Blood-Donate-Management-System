'use strict';

function render() {
  const current = route();
  document.documentElement.lang = state.lang;
  document.documentElement.dir = t('dir');
  document.title = t('brand');
  document.getElementById('skip-link').textContent = t('skip');
  const pageContent = current === '/' ? homePage() : current === '/donate' ? donationPage() : current === '/compatibility' ? compatibilityPage() : current === '/about' ? aboutPage() : notFoundPage();
  app.innerHTML = header(current) + pageContent + footer();
  bindGlobalEvents();
  if (current === '/donate') bindDonationForm();
  if (current === '/compatibility') bindCompatibility();
}

function bindGlobalEvents() {
  document.querySelectorAll('[data-link]').forEach(function(link) { link.addEventListener('click', function(event) { if (!event.ctrlKey && !event.metaKey) { event.preventDefault(); navigate(link.getAttribute('href')); } }); });
  document.getElementById('lang-toggle').addEventListener('click', function() { state.lang = state.lang === 'ar' ? 'en' : 'ar'; localStorage.setItem(APP_CONFIG.languageKey,state.lang); render(); });
  const menu = document.getElementById('main-nav');
  const toggle = document.getElementById('menu-toggle');
  toggle.addEventListener('click', function() { const open = menu.classList.toggle('open'); toggle.setAttribute('aria-expanded',String(open)); toggle.textContent = open ? '×' : '☰'; });
}

function setError(id, message) {
  const input = document.getElementById(id);
  const error = document.getElementById(id + '-error');
  if (error) error.textContent = message || '';
  if (input) input.classList.toggle('invalid',Boolean(message));
}

function bindDonationForm() {
  const form = document.getElementById('donation-form');
  const checks = Array.from(form.querySelectorAll('input[name="conditions"]'));
  checks.forEach(function(check) { check.addEventListener('change', function() {
    if (check.value === 'none' && check.checked) checks.filter(function(c){return c.value !== 'none';}).forEach(function(c){c.checked=false;});
    if (check.value !== 'none' && check.checked) checks.find(function(c){return c.value === 'none';}).checked=false;
    setError('conditions','');
  }); });
  form.addEventListener('input', function(event) { if (event.target.id) setError(event.target.id,''); });
  form.addEventListener('submit', handleDonationSubmit);
}

function handleDonationSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  let valid = true;
  ['firstName','fatherName','grandfatherName','familyName','nationalId','phone','age','bloodGroup','governorate','street','address'].forEach(function(id){
    const el = document.getElementById(id); const empty = !String(el.value).trim(); setError(id,empty?t('required'):''); if(empty) valid=false;
  });
  const nameIds = ['firstName','fatherName','grandfatherName','familyName'];
  nameIds.forEach(function(id){ const el=document.getElementById(id); if(el.value.trim() && el.value.trim().length<2){setError(id,t('fourName'));valid=false;} });
  const national = document.getElementById('nationalId').value.trim();
  if (national && !/^\d{10}$/.test(national)) { setError('nationalId',t('invalidNational')); valid=false; }
  const phone = document.getElementById('phone').value.replace(/[\s-]/g,'');
  if (phone && !/^(?:\+962|00962|0)7[789]\d{7}$/.test(phone)) { setError('phone',t('invalidPhone')); valid=false; }
  const gender = form.querySelector('input[name="gender"]:checked');
  document.getElementById('gender-error').textContent = gender ? '' : t('required'); if(!gender) valid=false;
  const age = Number(document.getElementById('age').value);
  if (document.getElementById('age').value && (!Number.isInteger(age) || age < APP_CONFIG.donationAge.min || age > APP_CONFIG.donationAge.max)) { setError('age',t('invalidAge',{min:APP_CONFIG.donationAge.min,max:APP_CONFIG.donationAge.max})); valid=false; }
  const selected = Array.from(form.querySelectorAll('input[name="conditions"]:checked')).map(function(c){return c.value;});
  if (!selected.length) { setError('conditions',t('chooseCondition')); valid=false; }
  if (selected.includes('none') && selected.length > 1) { setError('conditions',t('conditionConflict')); valid=false; }
  const confirmed = document.getElementById('confirm').checked;
  setError('confirm',confirmed?'':t('mustConfirm')); if(!confirmed) valid=false;
  if (!valid) { const first = form.querySelector('.invalid') || form.querySelector('.error:not(:empty)'); if(first) first.scrollIntoView({behavior:'smooth',block:'center'}); return; }
  const disqualifying = selected.filter(function(id){return id !== 'none';});
  if (disqualifying.length) {
    const names = disqualifying.map(function(id){return disqualifyingConditions.find(function(c){return c.id===id;})[state.lang];}).join(state.lang==='ar'?'، ':', ');
    showModal('error',t('rejectedTitle'),t('rejectedConditions',{conditions:names}));
    return;
  }
  const group = document.getElementById('bloodGroup').value;
  // Production inventory must update only after collection, medical screening, and confirmation by authorized staff.
  state.inventory[group] += 1;
  saveInventory();
  form.reset();
  showModal('success',t('acceptedTitle'),t('acceptedMessage',{group:group}));
}

function showModal(type, title, message) {
  const modal = document.getElementById('app-modal');
  const icon = document.getElementById('modal-icon');
  icon.className = 'modal-icon ' + (type === 'error' ? 'error' : '');
  icon.textContent = type === 'error' ? '!' : '✓';
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-message').textContent = message;
  document.getElementById('modal-close').textContent = t('ok');
  document.getElementById('modal-close').onclick = function(){ modal.close(); };
  modal.showModal();
}

function bindCompatibility() {
  document.getElementById('compat-test').addEventListener('click', function(){
    const donor = document.getElementById('donorType'); const recipient = document.getElementById('recipientType');
    setError('donorType',donor.value?'':t('required')); setError('recipientType',recipient.value?'':t('required'));
    if(!donor.value || !recipient.value) return;
    const compatible = RBC_COMPATIBILITY[donor.value].includes(recipient.value);
    const result = document.getElementById('compat-result');
    result.className = 'result-panel show ' + (compatible?'ok':'no');
    result.innerHTML = '<div class="result-symbol">'+(compatible?'✓':'×')+'</div><div><strong>'+t(compatible?'compatible':'notCompatible')+'</strong><p>'+t(compatible?'compatibleText':'notCompatibleText',{donor:donor.value,recipient:recipient.value})+'</p></div>';
  });
}

window.addEventListener('hashchange',render);
render();

