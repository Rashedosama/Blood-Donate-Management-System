'use strict';

const RBC_COMPATIBILITY = Object.freeze({
  'O−': Object.freeze(['O−','O+','A−','A+','B−','B+','AB−','AB+']),
  'O+': Object.freeze(['O+','A+','B+','AB+']),
  'A−': Object.freeze(['A−','A+','AB−','AB+']),
  'A+': Object.freeze(['A+','AB+']),
  'B−': Object.freeze(['B−','B+','AB−','AB+']),
  'B+': Object.freeze(['B+','AB+']),
  'AB−': Object.freeze(['AB−','AB+']),
  'AB+': Object.freeze(['AB+'])
});

