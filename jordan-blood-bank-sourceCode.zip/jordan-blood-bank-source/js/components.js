'use strict';

const state = { lang: localStorage.getItem(APP_CONFIG.languageKey) === 'en' ? 'en' : 'ar', inventory: loadInventory() };
const app = document.getElementById('app');

function t(key, replacements) {
  let value = I18N[state.lang][key];
  if (replacements && typeof value === 'string') Object.keys(replacements).forEach(function(k) { value = value.replace('{' + k + '}', replacements[k]); });
  return value;
}

function loadInventory() {
  try {
    const stored = JSON.parse(localStorage.getItem(APP_CONFIG.inventoryKey));
    if (stored && APP_CONFIG.bloodGroups.every(function(group) { return Number.isFinite(stored[group]); })) return stored;
  } catch (error) { void error; }
  return Object.assign({}, APP_CONFIG.defaultInventory);
}

function saveInventory() { localStorage.setItem(APP_CONFIG.inventoryKey, JSON.stringify(state.inventory)); }
function route() { const path = (location.hash.slice(1) || '/').replace(/\/+$/, '') || '/'; return ['/', '/donate', '/compatibility', '/about'].includes(path) ? path : '/404'; }
function navigate(path) { if (route() !== path) location.hash = path; else render(); window.scrollTo({ top: 0, behavior: 'smooth' }); }

function brand() {
  return '<span class="brand-mark" aria-hidden="true"></span><span class="brand-copy"><strong>' + t('brand') + '</strong><small>' + t('brandSub') + '</small></span>';
}

function header(current) {
  const links = [ ['/', 'home'], ['/donate','donate'], ['/compatibility','compatibility'], ['/about','about'] ];
  return '<div class="notice-bar">' + t('educational') + '</div>' +
    '<header class="site-header"><div class="container nav-shell">' +
    '<a href="/" class="brand" data-link aria-label="' + t('home') + '">' + brand() + '</a>' +
    '<nav class="main-nav" id="main-nav" aria-label="Primary navigation">' + links.map(function(item) {
      return '<a href="' + item[0] + '" data-link class="nav-link ' + (current === item[0] ? 'active' : '') + '">' + t(item[1]) + '</a>';
    }).join('') + '</nav>' +
    '<div class="nav-actions"><button class="lang-btn" id="lang-toggle" type="button" aria-label="Change language">' + t('langName') + '</button><button class="icon-btn" id="menu-toggle" type="button" aria-controls="main-nav" aria-expanded="false" aria-label="Menu">☰</button></div>' +
    '</div></header>';
}

function footer() {
  return '<footer class="site-footer"><div class="container footer-main">' +
    '<div class="footer-brand"><div class="brand">' + brand() + '</div><p>' + t('footerText') + '</p></div>' +
    '<div class="footer-col"><h3>' + t('quickLinks') + '</h3><div class="footer-links"><a href="/" data-link>' + t('home') + '</a><a href="/donate" data-link>' + t('donate') + '</a><a href="/compatibility" data-link>' + t('compatibility') + '</a><a href="/about" data-link>' + t('about') + '</a></div></div>' +
    '<div class="footer-col"><h3>' + t('awareness') + '</h3><div class="footer-links"><span>' + t('educational') + '</span><span>' + t('disclaimer') + '</span></div></div>' +
    '</div><div class="container footer-bottom"><span>' + t('rights') + '</span><span>' + t('footerStatus') + '</span></div></footer>';
}

function pageHero(eye, title, lead) {
  return '<section class="page-hero"><div class="container"><span class="eyebrow">' + eye + '</span><h1>' + title + '</h1><p>' + lead + '</p></div></section>';
}

function bloodCard(group) {
  const count = state.inventory[group];
  const low = count < APP_CONFIG.lowStockThreshold;
  const width = Math.min(100, Math.round((count / APP_CONFIG.targetUnitsPerGroup) * 100));
  return '<article class="blood-card"><div class="blood-top"><div class="blood-type">' + group + '</div><span class="stock-status ' + (low ? 'low' : '') + '">' + t(low ? 'low' : 'available') + '</span></div>' +
    '<div class="blood-count"><strong>' + count + '</strong><span>' + t('unit') + '</span></div><div class="progress" role="progressbar" aria-label="' + group + '" aria-valuenow="' + width + '" aria-valuemin="0" aria-valuemax="100"><span class="' + (low ? 'low' : '') + '" style="width:' + width + '%"></span></div><p class="card-update">' + t('lastUpdate') + ': ' + t('updateNow') + '</p></article>';
}

function field(id, label, type, extra) {
  extra = extra || {};
  return '<div class="field ' + (extra.full ? 'full' : '') + '"><label class="required" for="' + id + '">' + label + '</label><input class="input" id="' + id + '" name="' + id + '" type="' + type + '" ' + (extra.inputmode ? 'inputmode="' + extra.inputmode + '" ' : '') + (extra.autocomplete ? 'autocomplete="' + extra.autocomplete + '" ' : '') + 'required><span class="error" id="' + id + '-error"></span></div>';
}

function selectField(id, label, options, extraClass) {
  return '<div class="field ' + (extraClass || '') + '"><label class="required" for="' + id + '">' + label + '</label><select id="' + id + '" name="' + id + '" required><option value="">' + t('choose') + '</option>' + options + '</select><span class="error" id="' + id + '-error"></span></div>';
}

