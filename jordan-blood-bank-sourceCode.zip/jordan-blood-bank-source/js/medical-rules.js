'use strict';

// Educational starter list. Final exclusions must be reviewed against Jordanian Ministry of Health and approved blood-bank policies.
const disqualifyingConditions = Object.freeze([
  { id: 'none', ar: 'لا أعاني من أيٍّ منها', en: 'I do not have any of these conditions' },
  { id: 'sickle_cell', ar: 'فقر الدم المنجلي', en: 'Sickle cell disease' },
  { id: 'thalassemia', ar: 'الثلاسيميا', en: 'Thalassemia' },
  { id: 'hemophilia', ar: 'الهيموفيليا أو اضطراب نزف خطير', en: 'Hemophilia or serious bleeding disorder' },
  { id: 'blood_cancer', ar: 'سرطان الدم أو سرطان الغدد اللمفاوية', en: 'Leukemia or lymphoma' },
  { id: 'active_cancer', ar: 'سرطان نشط أو علاج سرطان جارٍ', en: 'Active cancer or ongoing cancer treatment' },
  { id: 'hiv', ar: 'فيروس نقص المناعة البشرية', en: 'HIV infection' },
  { id: 'hepatitis', ar: 'التهاب الكبد الفيروسي B أو C', en: 'Viral hepatitis B or C' },
  { id: 'active_infection', ar: 'عدوى خطيرة نشطة', en: 'Serious active infection' },
  { id: 'severe_heart', ar: 'مرض قلبي خطير أو قصور قلب', en: 'Severe heart disease or heart failure' },
  { id: 'severe_liver', ar: 'مرض كبدي مزمن متقدم', en: 'Advanced chronic liver disease' },
  { id: 'severe_kidney', ar: 'فشل كلوي أو مرض كلوي متقدم', en: 'Kidney failure or advanced kidney disease' },
  { id: 'blood_disorder', ar: 'اضطراب دموي خطير آخر', en: 'Another serious blood disorder' },
  { id: 'uncontrolled_diabetes', ar: 'سكري غير مسيطر عليه مع مضاعفات', en: 'Uncontrolled diabetes with complications' }
]);

